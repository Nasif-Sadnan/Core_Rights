<?php
    header("Location: Layout/View/Home.php");
?>