function ShowAbout(){
    document.getElementById("About").style.display = "block";
}

function ShowREP(){ 
    document.getElementById("About").style.display = "none";
}


function ShowVLN(){
    
}

function ShowREP(){

}