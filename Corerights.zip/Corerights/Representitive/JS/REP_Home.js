function ShowAbout(){
    document.getElementById("About").style.display = "block";
}

function ShowComplain(){
}

function ShowMin(){
}

function ShowVLN(){

}

function ShowREP(){

}