function ShowAbout(){
    document.getElementById("About").style.display = "block";
    document.getElementById("comp").style.display = "none";
}

function ShowComplain(){
    document.getElementById("About").style.display = "none";
    document.getElementById("comp").style.display = "block";
}

function ShowMin(){
}

function ShowUser(){

}